<?php include_once("includes/basic_includes.php");?>
<?php include_once("functions.php"); ?>
<?php

$id=$_GET['id'];
if(isloggedin()){
 //do nothing stay here
} else{
   header("location:login.php");
}

 
$id=$_GET['id'];
//safty purpose copy the get id
$profileid=$id;

//getting profile details from db
$sql="SELECT * FROM customer WHERE cust_id = $id";
$result = mysqlexec($sql);
if($result){
$row=mysqli_fetch_assoc($result);

  $fname=$row['firstname'];
  $lname=$row['lastname'];
  

//end of getting profile detils



  $pic1="";
  $pic2="";
  $pic3="";
  $pic4="";
//getting image filenames from db
$sql2="SELECT * FROM customer WHERE cust_id = $profileid";
$result2 = mysqlexec($sql2);
if($result2){
  $row2=mysqli_fetch_array($result2);
  $pic1=$row2['pic1'];
  $pic2=$row2['pic2'];
  $pic3=$row2['pic3'];
  $pic4=$row2['pic4'];
}
}else{
  echo "<script>alert(\"Invalid Profile ID\")</script>";
}

?>

<!DOCTYPE HTML>
<html>

<head>
    <title>Find Your Perfect Partner - Matrimony
        | User Home :: Matrimony
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <script type="application/x-javascript">
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
    </script>
    <link href="css/bootstrap-3.1.1.min.css" rel='stylesheet' type='text/css' />
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- Custom Theme files -->
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href='//fonts.googleapis.com/css?family=Oswald:300,400,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
    <!--font-Awesome-->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!--font-Awesome-->
    <script>
    $(document).ready(function() {
        $(".dropdown").hover(
            function() {
                $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                $(this).toggleClass('open');
            },
            function() {
                $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                $(this).toggleClass('open');
            }
        );
    });
    </script>
</head>

<body>
    <!-- ============================  Navigation Start =========================== -->
    <?php include_once("includes/navigation.php");?>
    <!-- ============================  Navigation End ============================ -->

    <div class="container profile">
        <div class="row">
            <div class="col-md-8 profile_left">
                <h2>Profile Id : <?php echo $profileid;?></h2>

                <div class="col_3">
                    <div class="col-sm-4 row_2">
                        <div class="flexslider">
                            <ul class="slides">
                                <li data-thumb="profile/<?php echo $profileid;?>/<?php echo $pic1;?>">
                                    <img src="profile/<?php echo $profileid;?>/<?php echo $pic1;?>" />
                                </li>
                                <!-- <li data-thumb="profile/<?php echo $profileid;?>/<?php echo $pic2;?>">
              <img src="profile/<?php echo $profileid;?>/<?php echo $pic2;?>" />
            </li>
            <li data-thumb="profile/<?php echo $profileid;?>/<?php echo $pic3;?>">
              <img src="profile/<?php echo $profileid;?>/<?php echo $pic3;?>" />
            </li>
            <li data-thumb="profile/<?php echo $profileid;?>/<?php echo $pic4;?>">
              <img src="profile/<?php echo $profileid;?>/<?php echo $pic4;?>" />
            </li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4 row_1">
                        <table class="table_working_hours">
                            <tbody>
                                <tr class="opened_1">
                                    <!-- <td class="day_label">Name :</td> -->
                                    <td class="day_value" style="font-size: 30px;"><?php echo $fname . " " .$lname; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- <div class="col-sm-4 row_1">
      </div> -->
                </div>
            </div>
        </div>
<br>
<br>

        <?php
        include 'includes/dbconn.php';
// $cust_info = array(

//     'id' =>  $_GET["id"],
//     'l'  =>  $_POST["age"],
//     'a'  =>   $_POST["maritalstatus"],
//     'b'  =>   $_POST["colour"],
//     'C'  =>   $_POST["height"],
//     'd'  =>   $_POST["diet"],
//     'e'  =>   $_POST["religion"],
//     'f'  =>   $_POST["caste"],
//     'g'  =>   $_POST["subcaste"],
//     'h'  =>   $_POST["mothertounge"],
//     'i'  =>   $_POST["education"],
//     'j'  =>   $_POST["occupation"],
//     'k'  =>   $_POST["country"] 
// );

// $q="SELECT custid FROM partnerprefs WHERE $age = $cust_info['l'] AND 
//                                     $maritalstatus = $cust_info['a'] AND
//                                     $colour = $cust_info['b'] AND
//                                     $height = $cust_info['c'] AND
//                                     $diet = $cust_info['d'] AND
//                                     $religion = $cust_info['e'] AND
//                                     $caste = $cust_info['f'] AND
//                                     $subcaste = $cust_info['g'] AND
//                                     $mothertounge = $cust_info['h'] AND
//                                     $education = $cust_info['i'] AND
//                                     $occupation = $cust_info['j'] AND
//                                     $country = $cust_info['k']";

$q= "SELECT custid FROM partnerprefs WHERE religion='Hindu' AND education='Primary'";
// $q = "SELECT * FROM customer WHERE religion = '".$_GET['religion']."' AND education = '".$_GET['education']."'";
// $result = mysqlexec($sql);
// if($result){
// $row=mysqli_fetch_assoc($result);
// }
$result = mysqli_query($conn, $q);
$i= 0;
$cust_ids =array();
while($row = mysqli_fetch_assoc($result)){
  $cust_ids[$i] = $row['custid'];
  $i++;
    } 
    
    $commaList = implode(', ', $cust_ids);

//     $q1="SELECT * FROM photos 
// JOIN customer ON customer.cust_id=photos.cust_id 
// IN ($commaList)";
    
    $q1 = "SELECT * FROM  customer WHERE  cust_id IN ($commaList) AND cust_id!=$id";
    // echo $q1;
    $result1 = mysqli_query($conn, $q1);
    while($row1 = mysqli_fetch_assoc($result1)){
        // echo $row1['email'];

?>
     
     <div >
                        <table >
                            <tbody>
                            <div class="col-md-5">
                            <td><?php echo $row1['pic1']; ?></td>
                            </div>
                            <div class="col-md-7">
                                <tr >
                                <td><?php echo $row1['pic1'];?></td>
                                    <td><?php echo $row1['email']; ?></td><br>
                                    <td><?php echo $row1['age']; ?></td><br>
                                    <td><?php echo $row1['religion']; ?></td><br>
                                    <td><?php echo $row1['caste']; ?></td>
                                </tr>
                                </div>
                            </tbody>
                        </table>
</div>
    <?php } ?>


</div>
        <br>

        <?php include_once("footer.php")?>
        <!-- FlexSlider -->
        <script defer src="js/jquery.flexslider.js"></script>
        <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
        <script>
        // Can also be used with $(document).ready()
        $(window).load(function() {
            $('.flexslider').flexslider({
                animation: "slide",
                controlNav: "thumbnails"
            });
        });
        </script>
</body>

</html>